package custom_exceptions;

@SuppressWarnings("serial")
public class UserHandlingException extends Exception {
	public UserHandlingException(String message) {
		super(message);
	}

}
