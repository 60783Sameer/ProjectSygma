package com.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.AddressRepository;
import com.app.entities.Address;

import custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class AddressServiceImpl implements IAddressService {
@Autowired
private AddressRepository addressRepo;
	
	@Override
	public Address addAddress(Address transientAdd) {
		// TODO Auto-generated method stub
		
		return addressRepo.save(transientAdd);
	}

	

	@Override
	public String deleteAddress(int addressId) {
		// TODO Auto-generated method stub
		addressRepo.deleteById(addressId);;
		return "Address details deleted for Add id " +addressId;
	}

	@Override
	public Address updateAddressDetails(Address detachedAddress) {
		// TODO Auto-generated method stub
		if(addressRepo.existsById(detachedAddress.getAddressId()))
		return addressRepo.save(detachedAddress);
		
		throw new ResourceNotFoundException("Invalid Address ID : Updation Failed !!!!!!!!!" + detachedAddress.getAddressId());
		}



	@Override
	public Address getAddDetails(int addressId) {
		// TODO Auto-generated method stub
		return addressRepo.findById(addressId).orElseThrow(() -> new ResourceNotFoundException("Invalid Address ID " + addressId));
		
	}
}
