package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Cart;
import com.app.entities.Product;
import com.app.service.ICartService;

@RequestMapping("/api/cart")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class CartController {
	@Autowired
	private ICartService cartService;
	public CartController() {
		System.out.println("in cart " + getClass());
	}
	
	@PostMapping
	public ResponseEntity<?> addToCart(@RequestBody  Cart transientProd ,@RequestParam Long productId,@RequestParam int orderId) {
		System.out.println("in add dtls " + transientProd);
		try {
			// invoke service layer method
			return new ResponseEntity<>(cartService.addToCart1(transientProd,productId,orderId) , HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("err in add emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.BAD_REQUEST);// => invalid data from
																									// clnt
		}
	}
	
	@DeleteMapping("/{cartId}")
	public ResponseEntity<?> deleteFromCart(@PathVariable int cartId) {
		System.out.println("in del emp " + cartId);
		try {
			return ResponseEntity.ok(new ApiResponse(cartService.deleteFromCart(cartId)));
		} catch (RuntimeException e) {
			System.out.println("err in del  emp " + e);
			return new ResponseEntity<>(new ApiResponse("Invalid Cart ID !!!!!!!!!!!!!!!!"), HttpStatus.NOT_FOUND);// =>
																													// invalid																												// emp																											// id
		}
	}
	@PutMapping("/{cartId}")
	public ResponseEntity<?> updateProdDetails(@RequestBody Cart detachedCart,@RequestParam Long productId,@RequestParam int orderId) {

		System.out.println("in update prod " + detachedCart);
		try {
			return ResponseEntity.ok(cartService.updateCartDetails(detachedCart,productId,orderId));
		} catch (RuntimeException e) {
			System.out.println("err in update  emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
																								// invalid
																								// emp
																								// id
		}
	}

}
