package com.app.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@ToString
@Getter
@Setter
@Entity
public class Address {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)

	private int addressId;
	private String address;
	private String city;
	private int pinCode;
	private String state;
	private String country;
	
}
