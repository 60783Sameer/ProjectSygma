package com.app.entities;

public enum AcctType {
	USER

}
