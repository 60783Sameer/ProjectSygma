package com.app.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ChangePasswordDTO {

	@NotBlank(message = "Old password can not be blank")
	private String oldPassword;
	@NotBlank(message = "New password can not be blank")
	private String newPassword;

}
