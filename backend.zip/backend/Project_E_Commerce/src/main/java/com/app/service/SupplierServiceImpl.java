package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.ProductRepository;
import com.app.dao.SupplierRepository;
import com.app.entities.Address;
import com.app.entities.Product;
import com.app.entities.Supplier;

import custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class SupplierServiceImpl implements ISupplierService {
	@Autowired
	private SupplierRepository suppRepo;
	@Autowired
	private ProductRepository prodRepo;
	@Autowired
	//private Add
	
	@Override
	public List<Supplier> getAllSupplier() {
		// TODO Auto-generated method stub
		return suppRepo.findAll();
	}
	
//	Product p = proRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Invalid product id !!!!!!!"));
//	transientCart.setProducts(p);

	@Override
	public Supplier addSupplier(Supplier transientSupplier,Long productId) {
		List<Product> p = prodRepo.findAll();
		transientSupplier.setProducts(p);
		//Address a = 
		
		return suppRepo.save(transientSupplier);
	}

	@Override
	public String deleteSupplier(int orderId) {
		suppRepo.deleteById(orderId);
		return "Supplier deleted " + orderId ;
	}

	@Override
	public Supplier getSupplierDetails(int orderId) {
		return suppRepo.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID " + orderId));
		
	}

	@Override
	public Supplier updateSupplierDetails(Supplier detachedSupplier) {
		if (suppRepo.existsById(detachedSupplier.getSupplierId()))
			return suppRepo.save(detachedSupplier);//update
		throw new ResourceNotFoundException("Invalid Prod ID : Updation Failed !!!!!!!!!" + detachedSupplier.getSupplierId());
	
	}
	

}
