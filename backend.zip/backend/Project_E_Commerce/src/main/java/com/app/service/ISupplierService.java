package com.app.service;

import java.util.List;

import com.app.entities.Supplier;

public interface ISupplierService {
	List<Supplier> getAllSupplier();
	Supplier addSupplier(Supplier transientSupplier,Long productId);
	String deleteSupplier(int orderId);
	Supplier getSupplierDetails(int orderId);
	Supplier updateSupplierDetails(Supplier detachedSupplier);
	
}
