package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import custom_exceptions.ResourceNotFoundException;
import com.app.dao.ProductRepository;
import com.app.entities.Product;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
@Autowired
private ProductRepository prodRepo;
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		
		return prodRepo.findAll();
	}

	@Override
	public Product addProd(Product transientPro) {
		// TODO Auto-generated method stub
		
		return prodRepo.save(transientPro);
	}

	@Override
	public String deleteProd(long productId) {
		// TODO Auto-generated method stub
		prodRepo.deleteById(productId);
		return "Prod details deleted for prod id " + productId;
	}

	@Override
	public Product getProdDetails(long productId) {
		// TODO Auto-generated method stub
		
		return prodRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID " + productId));
		
	}

	@Override
	public Product updateProdDetails(Product detachedProd) {
		if (prodRepo.existsById(detachedProd.getProductId()))
			return prodRepo.save(detachedProd);//update
		throw new ResourceNotFoundException("Invalid Prod ID : Updation Failed !!!!!!!!!" + detachedProd.getProductId());
	
	}

}
