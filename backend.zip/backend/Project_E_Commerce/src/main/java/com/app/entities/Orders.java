package com.app.entities;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
@Entity
@Table(name="orders")
public class Orders{
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int orderId;
	private Date orderDate;
	private float totalAmount;
	@Enumerated(EnumType.STRING)
	private TransactionStatus status;
	
	
}
