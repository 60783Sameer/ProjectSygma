package com.app.entities;

public enum TransactionStatus {
		TRANSACTION_SUCCESFULL,TRANSACTION_FAIL;
}
