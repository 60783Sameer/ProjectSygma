package com.app.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Orders;
import com.app.service.IOrderService;


@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class OrderController {
	@Autowired
	private IOrderService orderService;
	public OrderController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	private List<Orders> listOrders(){
		System.out.println("Orders List");
		return orderService.getAllOrders();
		
	}
	@PostMapping
	public ResponseEntity<?> addOrderDetails(@RequestBody  Orders transientOrder) {
		System.out.println("in add dtls " + transientOrder);
		try {
			// invoke service layer method
			return new ResponseEntity<>(orderService.addOrders(transientOrder), HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("err in add emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.BAD_REQUEST);// => invalid data from
																									// clnt
		}
	}
	
	@DeleteMapping("/{orderId}")
	public ResponseEntity<?> deleteOrderDetails(@PathVariable int orderId) {
		System.out.println("in del order " + orderId );
		try {
			return ResponseEntity.ok(new ApiResponse(orderService.deleteOrder(orderId)));
		} catch (RuntimeException e) {
			System.out.println("err in del  emp " + e);
			return new ResponseEntity<>(new ApiResponse("Invalid Order ID !!!!!!!!!!!!!!!!"), HttpStatus.NOT_FOUND);// =>
																													// invalid																													// emp																												// id
		}
	}
	
	@GetMapping("/{orderId}")
	public ResponseEntity<?> getProductDetails(@PathVariable  int orderId) {
		System.out.println("in get orders " + orderId);
	//	try {
			return ResponseEntity.ok(orderService.getOrderDetails(orderId));
//		} catch (RuntimeException e) {
//			System.out.println("err in get  emp " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
//																								// invalid
//																								// emp
//																								// id
//		}
	}

	// add REST API endpoint to update existing emp details
	@PutMapping("/{orderId}")
	public ResponseEntity<?> updateProdDetails(@RequestBody Orders detachedOrder) {

		System.out.println("in update prod " + detachedOrder);
		try {
			return ResponseEntity.ok(orderService.updateOrderDetails(detachedOrder));
		} catch (RuntimeException e) {
			System.out.println("err in update  emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>																								// invalid
																								// emp
																								// id
		}
	}

}
