package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.CartRepository;
import com.app.dao.OrderRepository;
import com.app.dao.ProductRepository;
import com.app.entities.Cart;
import com.app.entities.Orders;
import com.app.entities.Product;

import custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class CartServiceImpl implements ICartService {
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private ProductRepository proRepo;
	@Autowired
	private OrderRepository orderRepo;
	

	@Override
	public String deleteFromCart(int cartId) {
		cartRepo.deleteById(cartId);
		return "delete succesfully from cart " +cartId;
	}

	@Override
	public Cart addToCart1(Cart transientCart, Long productId,int orderId) {
		Product p = proRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Invalid product id !!!!!!!"));
		transientCart.setProducts(p);
		List<Orders> o = orderRepo.findAll();
		transientCart.setOrders(o);
		return cartRepo.save(transientCart);
	}

	@Override
	public Cart updateCartDetails(Cart updateCart,Long productId,int orderId) {
		Product p = proRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Invalid product id !!!!!!!"));
		updateCart.setProducts(p);
		List<Orders> o = orderRepo.findAll();
		updateCart.setOrders(o);
		if (cartRepo.existsById(updateCart.getCartId()))
			return cartRepo.save(updateCart);//update
		throw new ResourceNotFoundException("Invalid Prod ID : Updation Failed !!!!!!!!!" + updateCart.getCartId());
	
	}

}
