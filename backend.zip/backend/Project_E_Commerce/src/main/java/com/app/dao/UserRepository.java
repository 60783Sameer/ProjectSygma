package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {
//	finder method to find user with given user id
	public Optional<User> findByUserId(int userId);
	public Optional<User> findByEmail(String email);
	
//	method to find user by using name
	public User findByUserName(String username);

//	method to find user by using email
	public Optional<User> findByEmailAndPassword(String email, String password);

}