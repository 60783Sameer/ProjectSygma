package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Address;
import com.app.service.IAddressService;

@RequestMapping("/api/address")
@CrossOrigin(origins = "http://localhost:3000")
@Validated
@RestController
public class AddressController {
	@Autowired
	private IAddressService addService;
	
	public AddressController() {
		// TODO Auto-generated constructor stub
		System.out.println("in ctor of " + getClass());
	}
	
	

	@PostMapping
	public ResponseEntity<?> addAddressDetails(@RequestBody @Valid Address transientAdd) {
		System.out.println("in add dtls " + transientAdd);
		try {
			// invoke service layer method
			return new ResponseEntity<>(addService.addAddress(transientAdd)	, HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("err in add emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.BAD_REQUEST);// => invalid data from
																									// clnt
		}
	}
	
	@DeleteMapping("/{addressId}")
	public ResponseEntity<?> deleteAddressDetails(@PathVariable Integer addressId) {
		System.out.println("in del Address " +addressId );
		try {
			return ResponseEntity.ok(new ApiResponse(addService.deleteAddress(addressId)));
		} catch (RuntimeException e) {
			System.out.println("err in del  Address " + e);
			return new ResponseEntity<>(new ApiResponse("Invalid Address ID !!!!!!!!!!!!!!!!"), HttpStatus.NOT_FOUND);// =>
																													// invalid
																													// Address
																													// id
		}
	}
	@GetMapping("/{addressId}")
	public ResponseEntity<?> getAddressDetails(@PathVariable  int addressId) {
		System.out.println("in get Address " + addressId);
	//	try {
			return ResponseEntity.ok(addService.getAddDetails(addressId));
//		} catch (RuntimeException e) {
//			System.out.println("err in get  Address " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
//																								// invalid
//																								// Address
//																								// id
//		}
	}
	
	// add REST API endpoint to update existing Address details
	@PutMapping("/{addressId}")
	public ResponseEntity<?> updateAddressDetails(@RequestBody Address detachedAdd) {

		System.out.println("in update prod " + detachedAdd);
		try {
			return ResponseEntity.ok(addService.updateAddressDetails(detachedAdd));
		} catch (RuntimeException e) {
			System.out.println("err in update  Address " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
																								// invalid
																								// Address
																								// id
		}
	}

}
