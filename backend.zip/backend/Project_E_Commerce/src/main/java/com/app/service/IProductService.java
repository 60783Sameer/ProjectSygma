package com.app.service;

import java.util.List;

import com.app.entities.Product;

public interface IProductService  {
	List<Product> getAllProducts();
	Product addProd(Product transientPro);

	String deleteProd(long productId);

	Product getProdDetails(long productId);

	Product updateProdDetails(Product detachedProd);


}
