package com.app.service;

import com.app.entities.Address;

public interface IAddressService {
	
	Address addAddress(Address transientAddre);

	String deleteAddress(int addressId);

	Address getAddDetails(int addressId);

	Address updateAddressDetails(Address detachedAddress);
}
