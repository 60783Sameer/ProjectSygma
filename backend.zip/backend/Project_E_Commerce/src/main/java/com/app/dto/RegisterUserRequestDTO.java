package com.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class RegisterUserRequestDTO {
	private String userName;
	private String email;
	private long mobileNo;
    private	String password;

}
