package com.app.entities;

public enum Status {
	INCART,BOUGHT,DELETE

}
