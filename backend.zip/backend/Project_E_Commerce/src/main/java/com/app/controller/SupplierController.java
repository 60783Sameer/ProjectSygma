package com.app.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Supplier;
import com.app.service.ISupplierService;

@RequestMapping("/api/supplier")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class SupplierController {
	@Autowired
	private ISupplierService supplierService;
	
	public SupplierController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<Supplier> listOfSupplier() {
		System.out.println("list of Supplier");
		return supplierService.getAllSupplier();
	}

	@PostMapping
	public ResponseEntity<?> addEmpDetails(@RequestBody  Supplier transientSupplier,@RequestParam Long productId) {
		System.out.println("in add dtls " + transientSupplier);
		try {
			// invoke service layer method
			return new ResponseEntity<>(supplierService.addSupplier(transientSupplier,productId), HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("err in add emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.BAD_REQUEST);// => invalid data from
																									// clnt
		}
	}
	
	@DeleteMapping("/{supplierId}")
	public ResponseEntity<?> deleteEmpDetails(@PathVariable int supplierId) {
		System.out.println("in del emp " + supplierId);
		try {
			return ResponseEntity.ok(new ApiResponse(supplierService.deleteSupplier(supplierId)));
		} catch (RuntimeException e) {
			System.out.println("err in del  emp " + e);
			return new ResponseEntity<>(new ApiResponse("Invalid Emp ID !!!!!!!!!!!!!!!!"), HttpStatus.NOT_FOUND);// =>
																													// invalid
																													// emp
																													// id
		}
	}
	
	@GetMapping("/{supplierId}")
	public ResponseEntity<?> getProductDetails(@PathVariable  int supplierId) {
		System.out.println("in get emp " + supplierId);
	//	try {
			return ResponseEntity.ok(supplierService.getSupplierDetails(supplierId));
//		} catch (RuntimeException e) {
//			System.out.println("err in get  emp " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
//																								// invalid
//																								// emp
//																								// id
//		}
	}

	// add REST API endpoint to update existing emp details
	@PutMapping("/{supplierId}")
	public ResponseEntity<?> updateProdDetails(@RequestBody Supplier detachedSupplier) {

		System.out.println("in update prod " + detachedSupplier);
		try {
			return ResponseEntity.ok(supplierService.updateSupplierDetails(detachedSupplier));
		} catch (RuntimeException e) {
			System.out.println("err in update  emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);																		// id
		}
	}

}
