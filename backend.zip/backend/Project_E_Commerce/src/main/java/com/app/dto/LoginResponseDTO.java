package com.app.dto;


import java.util.Optional;

import com.app.entities.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class LoginResponseDTO {

	public LoginResponseDTO(String userName2, Optional<User> findById) {
		// TODO Auto-generated constructor stub
	}
	private String userName;
	
	
		
	

}
