package com.app.service;

import java.util.List;

import com.app.dto.ChangePasswordDTO;
import com.app.dto.LoginResponseDTO;
import com.app.dto.UserDTO;
import com.app.entities.Product;
import com.app.entities.User;

import custom_exceptions.UserHandlingException;

public interface IUserService {
	//List of users
	List<User> getAllUsers();

//	method to authenticate new user through given email and password
	
//	method to add new user
	public User addUser(User userDTO);
	
//	method to change password
	public String changePassword(ChangePasswordDTO passwordDTO, Integer uId) throws UserHandlingException;
	
//	method to edit profile
	public User updateUserDetails(User detachedUser) ;
	
//	method to delete account of user
	public String deleteAccount(Integer aId);
	
	
//	method to get user details
	public User getUserDetails(Integer userId);


	LoginResponseDTO authenticateUser(String email, String password);

}
