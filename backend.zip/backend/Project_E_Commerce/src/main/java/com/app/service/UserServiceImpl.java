package com.app.service;

import java.util.List;

import javax.security.auth.message.AuthStatus;
import javax.transaction.Transactional;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.UserRepository;
import com.app.dto.ChangePasswordDTO;
import com.app.dto.LoginResponseDTO;
import com.app.dto.UserDTO;
import com.app.entities.User;

import custom_exceptions.ResourceNotFoundException;
import custom_exceptions.UserHandlingException;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
	@Autowired
	private UserRepository userRepo;


//	public SignInDTO authenticateUser(int userId,String password) {
//		User user = userRepo.findByUserIdAndPassword(userId, password).orElseThrow(() -> new RuntimeException("Authentication failed"));
//		
//		return new SignInDTO(user.getUserName(),userRepo.findByUserId(user.getUserId()));
//	}
	

	@Override
	public User addUser(User userDTO) {
		
		return userRepo.save(userDTO);
	}

	@Override
	public String changePassword(ChangePasswordDTO passwordDTO, Integer uId) throws UserHandlingException {
		User user = userRepo.findById(uId).orElseThrow(() -> new UserHandlingException("Invalid user id"));
		if(passwordDTO.getOldPassword() == user.getPassword())
		{
			System.out.println("User  : " +user);
			user.setPassword(passwordDTO.getNewPassword());
			return "password changed Succesfully";
		}
		return "password dosen't matched";
	}

	

	@Override
	public String deleteAccount(Integer aId)  {

			userRepo.deleteById(aId);
			return "Account Deleted Succesfully " +  aId;
		
	}



	@Override
	public User getUserDetails(Integer userId) {
		return userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID " + userId));

	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User updateUserDetails(User detachedUser) {
		if (userRepo.existsById(detachedUser.getUserId()))
			return userRepo.save(detachedUser);//update
		throw new ResourceNotFoundException("Invalid Prod ID : Updation Failed !!!!!!!!!" + detachedUser.getUserId());
	
	}

	@Override
	public LoginResponseDTO authenticateUser(String email, String password) {
		User user = userRepo.findByEmailAndPassword(email, password).orElseThrow(() -> new RuntimeException("Authentication failed"));		
		return new LoginResponseDTO(user.getUserName(),userRepo.findByEmail(user.getEmail()));
	}

	

}
