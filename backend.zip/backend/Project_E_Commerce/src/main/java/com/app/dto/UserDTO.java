package com.app.dto;


public class UserDTO {
	private Long userId;
	private String userName;
	private int mobileNo;
	private String email;

}
