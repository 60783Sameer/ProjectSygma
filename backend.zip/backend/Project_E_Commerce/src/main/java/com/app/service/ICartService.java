package com.app.service;


import com.app.entities.Cart;

public interface ICartService {
	String deleteFromCart(int cartId);
	Cart addToCart1(Cart transientCart,Long productId,int orderId);
	Cart updateCartDetails(Cart updateCart, Long productId, int orderId);


}
