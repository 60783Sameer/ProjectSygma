package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.OrderRepository;
import com.app.entities.Orders;

import custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class OrdersServiceImpl implements IOrderService{
	
	@Autowired
	private OrderRepository orderRepo;

	@Override
	public List<Orders> getAllOrders() {

		return orderRepo.findAll();
	}

	@Override
	public Orders addOrders(Orders transientOrder) {
		return orderRepo.save(transientOrder);
	}

	@Override
	public String deleteOrder(int orderId) {
		orderRepo.deleteById(orderId);
		return "Order Deleted SuccesFully of OrderId" + orderId;
	}

	@Override
	public Orders getOrderDetails(int orderId) {

		return orderRepo.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Invalid Order ID " + orderId));
		
	}

	@Override
	public Orders updateOrderDetails(Orders detachedOrder) {
		if (orderRepo.existsById(detachedOrder.getOrderId()))
			return orderRepo.save(detachedOrder);//update
		throw new ResourceNotFoundException("Invalid Prod ID : Updation Failed !!!!!!!!!" + detachedOrder.getOrderId());
	}

}
