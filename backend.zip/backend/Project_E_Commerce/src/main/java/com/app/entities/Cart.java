package com.app.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="cart")
public class Cart {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Column(name = "cart_Id", length = 20)
	private int cartId;
    
    @Enumerated(EnumType.STRING)
	private Status status;
	
	private int quantity;
	@OneToOne
	@JoinColumn(name="fk_productId")
	private Product products;
	@OneToMany
	@JoinColumn(name="fk_cartId")
	private List<Orders> orders;
	
	
	
}
