package com.app.service;

import java.util.List;


import com.app.entities.Orders;

public interface IOrderService {

	List<Orders> getAllOrders();
	Orders addOrders(Orders transientOrder);
	String deleteOrder(int orderId);
	Orders getOrderDetails(int orderId);
	Orders updateOrderDetails(Orders detachedOrder);

}
