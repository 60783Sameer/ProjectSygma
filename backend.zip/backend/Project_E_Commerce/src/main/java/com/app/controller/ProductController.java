package com.app.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Product;
import com.app.service.IProductService;


@RequestMapping("/api/product")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ProductController {
	
	
	@Autowired
	private IProductService prodService;
	
	public ProductController() {
		// TODO Auto-generated constructor stub
		System.out.println("in ctor of " + getClass());

	}
	
	
	@GetMapping
	public List<Product> listProducts() {
		System.out.println("in list emps");
		return prodService.getAllProducts();
	}
	
	@PostMapping
	public ResponseEntity<?> addEmpDetails(@RequestBody @Valid Product transientProd) {
		System.out.println("in add dtls " + transientProd);
		try {
			// invoke service layer method
			return new ResponseEntity<>(prodService.addProd(transientProd)	, HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("err in add emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.BAD_REQUEST);// => invalid data from
																									// clnt
		}
	}
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<?> deleteEmpDetails(@PathVariable Long productId) {
		System.out.println("in del emp " + productId);
		try {
			return ResponseEntity.ok(new ApiResponse(prodService.deleteProd(productId)));
		} catch (RuntimeException e) {
			System.out.println("err in del  emp " + e);
			return new ResponseEntity<>(new ApiResponse("Invalid Emp ID !!!!!!!!!!!!!!!!"), HttpStatus.NOT_FOUND);// =>
																													// invalid
																													// emp
																													// id
		}
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<?> getProductDetails(@PathVariable  Long productId) {
		System.out.println("in get emp " + productId);
	//	try {
			return ResponseEntity.ok(prodService.getProdDetails(productId));
//		} catch (RuntimeException e) {
//			System.out.println("err in get  emp " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
//																								// invalid
//																								// emp
//																								// id
//		}
	}

	// add REST API endpoint to update existing emp details
	@PutMapping("/{productId}")
	public ResponseEntity<?> updateProdDetails(@RequestBody Product detachedProd) {

		System.out.println("in update prod " + detachedProd);
		try {
			return ResponseEntity.ok(prodService.updateProdDetails(detachedProd));
		} catch (RuntimeException e) {
			System.out.println("err in update  emp " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);// =>
																								// invalid
																								// emp
																								// id
		}
	}

}
