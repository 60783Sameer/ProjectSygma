package com.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
